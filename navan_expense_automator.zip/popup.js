document.getElementById('runNow').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    function: async () => {
      const stored = await chrome.storage.local.get('postTemplate');
      const { postTemplate } = stored;
      if (postTemplate) {
        await fetch(postTemplate.url, {
          method: postTemplate.method,
          headers: postTemplate.headers,
          body: postTemplate.body
        });
        alert('Expense submitted!');
      } else {
        alert('No saved expense template found.');
      }
    }
  });
});