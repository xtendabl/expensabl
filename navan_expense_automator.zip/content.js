(function() {
  const origFetch = window.fetch;
  window.fetch = async (...args) => {
    const response = await origFetch(...args);

    if (args[0].includes('/api/liquid/user/expenses')) {
      response.clone().json().then(data => {
        chrome.runtime.sendMessage({
          type: 'EXPENSE_DATA',
          payload: {
            method: 'POST',
            url: args[0],
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
          }
        });
      });
    }

    return response;
  };
})();