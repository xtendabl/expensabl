chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXPENSE_DATA') {
    const postTemplate = message.payload;
    chrome.storage.local.set({ postTemplate });

    chrome.alarms.create('remindToSubmit', { delayInMinutes: 4320 });
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'remindToSubmit') {
    chrome.notifications.create({
      type: 'basic',
      title: 'Expense Reminder',
      message: 'Time to log into Navan and re-submit this expense.',
      iconUrl: 'icon.png'
    });
  }
});